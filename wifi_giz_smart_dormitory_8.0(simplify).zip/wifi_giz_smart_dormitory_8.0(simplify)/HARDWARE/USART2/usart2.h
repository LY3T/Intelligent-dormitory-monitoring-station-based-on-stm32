#ifndef __USART2__
#define __USART2__
#include "stdio.h"	
#include "sys.h" 

#define SYN_BUSY PAin(7)


void TTSPlay(u8 bgm,u8 SoundVol,char *Text,...);

void TTS_printf(u8 bgm,u8 SoundVol,char* Text,...);

void USART_Configuration(void);
void USART_Send_Byte(u8 mydata);

#endif


